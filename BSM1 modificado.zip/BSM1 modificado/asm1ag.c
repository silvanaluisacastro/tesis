/*
 * ASM1 is a C-file S-function for IAWQ AS Model No 1.  
 *
 * Copyright: Ulf Jeppsson, IEA, Lund University, Lund, Sweden
 */

#define S_FUNCTION_NAME asm1ag

#include "simstruc.h"
#include <math.h>

#define XINIT   ssGetArg(S,0)
#define PAR	ssGetArg(S,1)
#define V	ssGetArg(S,2)
#define SOSAT	ssGetArg(S,3)

/*
 * mdlInitializeSizes - initialize the sizes array
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumContStates(    S, 20); /*13 number of continuous states - pasa a 15+3=18 */
    ssSetNumDiscStates(    S, 0);   /* number of discrete states - queda =  */
    ssSetNumInputs(        S, 21);   /* 16 number of inputs - pasa a 18+3=21  ,20+KLa */
    ssSetNumOutputs(       S, 20);   /* 15 number of outputs - pasa a 17+3=20 */
    ssSetDirectFeedThrough(S, 1);   /* direct feedthrough flag - queda =     */
    ssSetNumSampleTimes(   S, 1);   /* number of sample times - queda =      */
    ssSetNumSFcnParams(    S, 4);   /* number of input arguments - queda =   */
    ssSetNumRWork(         S, 0);   /* number of real work vector elements - queda =   */
    ssSetNumIWork(         S, 0);   /* number of integer work vector elements - queda = */
    ssSetNumPWork(         S, 0);   /* number of pointer work vector elements - queda = */
}

/*
 * mdlInitializeSampleTimes - initialize the sample times array
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}


/*
 * mdlInitializeConditions - initialize the states
 */
static void mdlInitializeConditions(double *x0, SimStruct *S)
{
int i;

for (i = 0; i < 20; i++) {
   x0[i] = mxGetPr(XINIT)[i]; // el i=19 es XINIT[19]=Caudal Q posic 20
}
// x0[14] = mxGetPr(XINIT)[14];/* agrego x0[13] (posicion 15) inicial de nanoAg  */
// x0[15] = mxGetPr(XINIT)[15];/* agrego x0[14] (posicion 16) inicial de Ag+ */
// x0[16] = mxGetPr(XINIT)[16];/* agrego x0[15] (posicion 17) inicial de nanoAgHeteroagregadas  */
// x0[17] = mxGetPr(XINIT)[17];/* agrego x0[16] (posicion 18) inicial de Ag2S, particulado  */
// x0[18] = mxGetPr(XINIT)[18];/* agrego x0[17] (posicion 19) inicial de Sulfuros  */
}


/*
 * mdlOutputs - compute the outputs
 */

static void mdlOutputs(double *y, double *x, double *u, SimStruct *S, int tid)
{
  double X_I2TSS, X_S2TSS, X_BH2TSS, X_BA2TSS, X_P2TSS;
  int i;

  X_I2TSS = mxGetPr(PAR)[19];
  X_S2TSS = mxGetPr(PAR)[20];
  X_BH2TSS = mxGetPr(PAR)[21];
  X_BA2TSS = mxGetPr(PAR)[22];
  X_P2TSS = mxGetPr(PAR)[23];
  /* X_Ag2S2TSS = mxGetPr(PAR)[x]; */

  for (i = 0; i < 13; i++) {
      y[i] = x[i];
  }

  y[13] = X_I2TSS*x[2]+X_S2TSS*x[3]+X_BH2TSS*x[4]+X_BA2TSS*x[5]+X_P2TSS*x[6];
  
  y[14] = x[14];   /* x[14]; agrego la salida para las AgNPs X_Ag */
  y[15] = x[15];   /* x[15]; agrego la salida para iones de Ag S_AgI */
  y[16] = x[16];   /* x[16]; agrego la salida para nano heteroagregadas X_AgTSS */
  y[17] = x[17];   /* x[17]; agrego la salida para sulfuro de Ag X_Ag2S */
  y[18] = x[18];   /* x[18]; agrego la salida para Sul */

  y[19] = u[19];  /* original u[14] antes ; x[13] Flow - luego Q y[19] = u[19];  */
}

/*
 * mdlUpdate - perform action at major integration time step
 */

static void mdlUpdate(double *x, double *u, SimStruct *S, int tid)
{
}

/*
 * mdlDerivatives - compute the derivatives
 */
static void mdlDerivatives(double *dx, double *x, double *u, SimStruct *S, int tid)
{

double mu_H, K_S, K_OH, K_NO, b_H, mu_A, K_NH, K_OA, b_A, ny_g, k_a, k_h, K_X, ny_h;
double Y_H, Y_A, f_P, i_XB, i_XP, b_d, k_sd, k_as, k_ho, K_AgI, K_AgH, alfabetaB, k_b;
double X_I2TSS, X_S2TSS, X_BH2TSS, X_BA2TSS, X_P2TSS;
double proc1, proc2, proc3, proc4, proc5, proc6, proc7, proc8, proc3x, proc9, proc10, proc11;
double reac1, reac2, reac3, reac4, reac5, reac6, reac7, reac8, reac9, reac10, reac11, reac12, reac13, reac16, reac17, reac18, reac19, reac20;
double vol, SO_sat, T;
double xtemp[20]; //xtemp: matriz de 20 variables de estado, antes xtemp[15]; original era double xtemp[13], es el Q?
int i;

mu_H = mxGetPr(PAR)[0];
K_S = mxGetPr(PAR)[1];
K_OH = mxGetPr(PAR)[2];
K_NO = mxGetPr(PAR)[3];
b_H = mxGetPr(PAR)[4];
mu_A = mxGetPr(PAR)[5];
K_NH = mxGetPr(PAR)[6];
K_OA = mxGetPr(PAR)[7];
b_A = mxGetPr(PAR)[8];
ny_g = mxGetPr(PAR)[9];
k_a = mxGetPr(PAR)[10];
k_h = mxGetPr(PAR)[11];
K_X = mxGetPr(PAR)[12];
ny_h = mxGetPr(PAR)[13];
Y_H = mxGetPr(PAR)[14];
Y_A = mxGetPr(PAR)[15];
f_P = mxGetPr(PAR)[16];
i_XB = mxGetPr(PAR)[17];
i_XP = mxGetPr(PAR)[18];
vol = mxGetPr(V)[0];
SO_sat = mxGetPr(SOSAT)[0];
b_d = -0.898*exp(-2.565*u[14]);//mxGetPr(PAR)[24];  /* agrego para que busque b_d en la matriz PAR */
k_sd = mxGetPr(PAR)[24];  /* agrego para que busque k_sd en la matriz PAR */
k_as = mxGetPr(PAR)[25];  /* agrego para que busque k_as en la matriz PAR */
k_ho = mxGetPr(PAR)[26];  /* agrego para que busque k_ho en la matriz PAR */
K_AgI = mxGetPr(PAR)[27];  /* agrego para que busque K_AgI en la matriz PAR */
K_AgH = mxGetPr(PAR)[28];  /* agrego para que busque K_AgH en la matriz PAR */
alfabetaB = mxGetPr(PAR)[29];  /* agrego para que busque alfa en la matriz PAR */
k_b = mxGetPr(PAR)[30];  /* agrego para que busque k_b en la matriz PAR */
X_I2TSS = mxGetPr(PAR)[19];
X_S2TSS = mxGetPr(PAR)[20];
X_BH2TSS = mxGetPr(PAR)[21];
X_BA2TSS = mxGetPr(PAR)[22];
X_P2TSS = mxGetPr(PAR)[23];

for (i = 0; i < 20; i++) {
   if (x[i] < 0.0)
     xtemp[i] = 0.0;
   else
     xtemp[i] = x[i];
}

if (u[20] < 0.0) // antes u[17]
      x[7] = fabs(u[20]); // antes u[17]


proc1 = mu_H*(xtemp[1]/(K_S+xtemp[1]))*(xtemp[7]/(K_OH+xtemp[7]))*xtemp[4];
proc2 = mu_H*(xtemp[1]/(K_S+xtemp[1]))*(K_OH/(K_OH+xtemp[7]))*(xtemp[8]/(K_NO+xtemp[8]))*ny_g*xtemp[4];
proc3 = mu_A*(xtemp[9]/(K_NH+xtemp[9]))*(xtemp[7]/(K_OA+xtemp[7]))*(K_AgI/(K_AgI+xtemp[15]))*(K_AgH/(K_AgH+xtemp[16]*((X_BA2TSS*xtemp[5])/(X_I2TSS*xtemp[2]+X_S2TSS*xtemp[3]+X_BH2TSS*xtemp[4]+X_BA2TSS*xtemp[5]+X_P2TSS*xtemp[6]))))*xtemp[5];
//proc3 = mu_A*(xtemp[9]/(K_NH+xtemp[9]))*(xtemp[7]/(K_OA+xtemp[7]))*xtemp[5]; // modificado para inhibicion por Ag+ y AgNPs agregadas a X_BA
/* in GPS-X they use proc3x instead of proc3 in the oxygen equation */
/* proc3x = mu_A*(xtemp[9]/(K_NH+xtemp[9]))*(xtemp[7]/(K_OH+xtemp[7]))*xtemp[5]; */
proc4 = b_H*xtemp[4];
proc5 = b_A*xtemp[5];
proc6 = k_a*xtemp[10]*xtemp[4];
proc7 = k_h*((xtemp[3]/xtemp[4])/(K_X+(xtemp[3]/xtemp[4])))*((xtemp[7]/(K_OH+xtemp[7]))+ny_h*(K_OH/(K_OH+xtemp[7]))*(xtemp[8]/(K_NO+xtemp[8])))*xtemp[4];
proc8 = proc7*xtemp[11]/xtemp[3];
if (u[20] > 0.0) // si hay oxigeno, ocurre disolucion, sino no
    proc9 = b_d*xtemp[14]; // agrego proceso 9 - Disolucion Oxidativa */
else
    proc9 = 0.0;
if (u[20] > 0.0) // si hay ox�geno la sulfuracion se detiene, porque no no hay mas sulfuro disponible
    proc10 = 0.0;
else
    proc10 = k_sd*((xtemp[15]/107.8682)*(xtemp[18]/33.07)); // Sulfuracion INDIRECTA esta en molaridad, divido por Peso molar
proc11 = -alfabetaB*(xtemp[14])+k_b*(xtemp[16]);//-alfa*beta*(xtemp[14]/1.4844e-16)*((X_I2TSS*xtemp[2]+X_S2TSS*xtemp[3]+X_BH2TSS*xtemp[4]+X_BA2TSS*xtemp[5]+X_P2TSS*xtemp[6])/6.69e-12)+k_b*(xtemp[16]/1.4844e-16); // Heteroagregacion/ruptura de AgNPs con TSS


reac1 = 0.0;
reac2 = (-proc1-proc2)/Y_H+proc7;
reac3 = 0.0;
reac4 = (1.0-f_P)*(proc4+proc5)-proc7;
reac5 = proc1+proc2-proc4;
reac6 = proc3-proc5;
reac7 = f_P*(proc4+proc5);
reac8 = -((1.0-Y_H)/Y_H)*proc1-((4.57-Y_A)/Y_A)*proc3;
reac9 = -((1.0-Y_H)/(2.86*Y_H))*proc2+proc3/Y_A;
reac10 = -i_XB*(proc1+proc2)-(i_XB+(1.0/Y_A))*proc3+proc6;
reac11 = -proc6+proc8;
reac12 = (i_XB-f_P*i_XP)*(proc4+proc5)-proc8;
reac13 = -i_XB/14*proc1+((1.0-Y_H)/(14.0*2.86*Y_H)-(i_XB/14.0))*proc2-((i_XB/14.0)+1.0/(7.0*Y_A))*proc3+proc6/14;

reac16 = proc9+proc11; //X_Ag, se agrega el coeficiente estequiometrico de la ecuacion balanceada 1 a 1//reac16 = 0.0;
reac17 = -proc9-2*proc10*(107.8682);// S_AgI, reac17 = 0.0; PMAg+=107.8682 g/mol
reac18 = -proc11; // X_AgTSS
reac19 = proc10*(215.7364); // X_Ag2S, PMAg2S=247.801 g/mol
reac20 = -proc10*(33.07); // Sul, PM_HS- =33.07 g/mol

dx[0] = 1.0/vol*(u[19]*(u[0]-x[0]))+reac1;
dx[1] = 1.0/vol*(u[19]*(u[1]-x[1]))+reac2;
dx[2] = 1.0/vol*(u[19]*(u[2]-x[2]))+reac3;
dx[3] = 1.0/vol*(u[19]*(u[3]-x[3]))+reac4;
dx[4] = 1.0/vol*(u[19]*(u[4]-x[4]))+reac5;
dx[5] = 1.0/vol*(u[19]*(u[5]-x[5]))+reac6;
dx[6] = 1.0/vol*(u[19]*(u[6]-x[6]))+reac7;
if (u[20] < 0.0)
      dx[7] = 0.0;
   else
      dx[7] = 1.0/vol*(u[19]*(u[7]-x[7]))+reac8+u[20]*(SO_sat-x[7]); // reac8+u[17]*(SO_sat-x[7])
dx[8] = 1.0/vol*(u[19]*(u[8]-x[8]))+reac9;
dx[9] = 1.0/vol*(u[19]*(u[9]-x[9]))+reac10;
dx[10] = 1.0/vol*(u[19]*(u[10]-x[10]))+reac11;
dx[11] = 1.0/vol*(u[19]*(u[11]-x[11]))+reac12;
dx[12] = 1.0/vol*(u[19]*(u[12]-x[12]))+reac13;
/*dx[13] = (u[14]-x[13])/T;   low pass filter for flow, avoid algebraic loops */
dx[13] = 0.0; /* TSS */
dx[14] = 1.0/vol*(u[19]*(u[14]-x[14]))+reac16; // X_Ag
dx[15] = 1.0/vol*(u[19]*(u[15]-x[15]))+reac17; // S_AgI
dx[16] = 1.0/vol*(u[19]*(u[16]-x[16]))+reac18; // X_AgTSS
dx[17] = 1.0/vol*(u[19]*(u[17]-x[17]))+reac19; // X_Ag2S
dx[18] = 1.0/vol*(u[19]*(u[18]-x[18]))+reac20; // Sul  
dx[19] = 0.0; /* Flow */
}


/*
 * mdlTerminate - called when the simulation is terminated.
 */
static void mdlTerminate(SimStruct *S)
{
}

#ifdef	MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
