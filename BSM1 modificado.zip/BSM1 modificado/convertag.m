load constinfluentag.ascii
a=constinfluentag;

CONSTINFLUENTAG=a;

%load dryinfluentag.ascii
%a=dryinfluentag;
%[m,n]=size(a);
%
%DRYINFLUENTAG=[a(:,1) a(:,7) a(:,2) a(:,5) a(:,4) a(:,3) ones(m,4)*0 a(:,6) a(:,8) a(:,9) ones(m,1)*7 (a(:,3)+a(:,4)+a(:,5))*0.75 a(:,10)];

%load storminfluentag.ascii
%a=storminfluentag;
%[m,n]=size(a);

%STORMINFLUENTAG=[a(:,1) a(:,7) a(:,2) a(:,5) a(:,4) a(:,3) ones(m,4)*0 a(:,6) a(:,8) a(:,9) ones(m,1)*7 (a(:,3)+a(:,4)+a(:,5))*0.75 a(:,10)];

%load raininfluentag.ascii
%a=raininfluentag;
%[m,n]=size(a);

%RAININFLUENTAG=[a(:,1) a(:,7) a(:,2) a(:,5) a(:,4) a(:,3) ones(m,4)*0 a(:,6) a(:,8) a(:,9) ones(m,1)*7 (a(:,3)+a(:,4)+a(:,5))*0.75 a(:,10)];

load sensornoise.ascii
a=sensornoise;
SENSORNOISE=a;

cd ..

save constinfluentag CONSTINFLUENTAG
%save dryinfluentag DRYINFLUENTAG
%save storminfluentag STORMINFLUENTAG
%save raininfluentag RAININFLUENTAG
save sensornoise SENSORNOISE
