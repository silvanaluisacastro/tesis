/*
 * combiner.c calculates the concentrations when adding two flow  
 * streams together.
 *  
 * Copyright: Ulf Jeppsson, IEA, Lund University, Lund, Sweden
 */

#define S_FUNCTION_NAME combinerag

#include "simstruc.h"


/*
 * mdlInitializeSizes - initialize the sizes array
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumContStates(    S, 0);   /* number of continuous states           */
    ssSetNumDiscStates(    S, 0);   /* number of discrete states             */
    ssSetNumInputs(        S, 40);   /* number of inputs antes eran 30 (15+15)*/
    ssSetNumOutputs(       S, 20);   /* number of outputs antes eran 15       */
    ssSetDirectFeedThrough(S, 1);   /* direct feedthrough flag               */
    ssSetNumSampleTimes(   S, 1);   /* number of sample times                */
    ssSetNumSFcnParams(    S, 0);   /* number of input arguments             */
    ssSetNumRWork(         S, 0);   /* number of real work vector elements   */
    ssSetNumIWork(         S, 0);   /* number of integer work vector elements*/
    ssSetNumPWork(         S, 0);   /* number of pointer work vector elements*/
}

/*
 * mdlInitializeSampleTimes - initialize the sample times array
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}


/*
 * mdlInitializeConditions - initialize the states
 */
static void mdlInitializeConditions(double *x0, SimStruct *S)
{
}

/*
 * mdlOutputs - compute the outputs
 */
/* u[19]: caudal port 1 y u[39]: caudal port 2 */
static void mdlOutputs(double *y, double *x, double *u, SimStruct *S, int tid)
{
  if ((u[19] > 0) || (u[39] > 0)) {
    y[0]=(u[0]*u[19] + u[20]*u[39])/(u[19]+u[39]); // SI
    y[1]=(u[1]*u[19] + u[21]*u[39])/(u[19]+u[39]); // SS
    y[2]=(u[2]*u[19] + u[22]*u[39])/(u[19]+u[39]); // XI
    y[3]=(u[3]*u[19] + u[23]*u[39])/(u[19]+u[39]); // XS
    y[4]=(u[4]*u[19] + u[24]*u[39])/(u[19]+u[39]); // XBH
    y[5]=(u[5]*u[19] + u[25]*u[39])/(u[19]+u[39]); // XBA
    y[6]=(u[6]*u[19] + u[26]*u[39])/(u[19]+u[39]); // XP
    y[7]=(u[7]*u[19] + u[27]*u[39])/(u[19]+u[39]); // SO
    y[8]=(u[8]*u[19] + u[28]*u[39])/(u[19]+u[39]); // SNO
    y[9]=(u[9]*u[19] + u[29]*u[39])/(u[19]+u[39]); // SNH
    y[10]=(u[10]*u[19] + u[30]*u[39])/(u[19]+u[39]); // SND
    y[11]=(u[11]*u[19] + u[31]*u[39])/(u[19]+u[39]); // XND
    y[12]=(u[12]*u[19] + u[32]*u[39])/(u[19]+u[39]); // SALK
    y[13]=(u[13]*u[19] + u[33]*u[39])/(u[19]+u[39]); // TSS
    y[14]=(u[14]*u[19] + u[34]*u[39])/(u[19]+u[39]); // X_Ag
    y[15]=(u[15]*u[19] + u[35]*u[39])/(u[19]+u[39]); // S_AgI
    y[16]=(u[16]*u[19] + u[36]*u[39])/(u[19]+u[39]); // X_AgTSS
    y[17]=(u[17]*u[19] + u[37]*u[39])/(u[19]+u[39]); // X_Ag2S
    y[18]=(u[18]*u[19] + u[38]*u[39])/(u[19]+u[39]); // Sul
    y[19]=(u[19]+u[39]); // Q = Q1+Q2
  }
  else {
    y[0]=0;
    y[1]=0;
    y[2]=0;
    y[3]=0;
    y[4]=0;
    y[5]=0;
    y[6]=0;
    y[7]=0;
    y[8]=0;
    y[9]=0;
    y[10]=0;
    y[11]=0;
    y[12]=0;
    y[13]=0;
    y[14]=0; // agregado X_Ag
    y[15]=0; // agregado S_AgI
    y[16]=0; // agregado X_AgTSS
    y[17]=0; // agregado X_Ag2S
    y[18]=0; // agregado Sul
    y[19]=0; // modificado Q output
    
  }
}

/*
 * mdlUpdate - perform action at major integration time step
 */

static void mdlUpdate(double *x, double *u, SimStruct *S, int tid)
{
}

/*
 * mdlDerivatives - compute the derivatives
 */
static void mdlDerivatives(double *dx, double *x, double *u, SimStruct *S, int tid)
{
}


/*
 * mdlTerminate - called when the simulation is terminated.
 */
static void mdlTerminate(SimStruct *S)
{
}

#ifdef	MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
