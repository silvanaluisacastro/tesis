olasm1initag; % se paso de olasm1init a olasm1initag

olsettler1dinitag;

load constinfluentag; % se cambi� para que tome el nvo archivo de entrada con AgNPs

