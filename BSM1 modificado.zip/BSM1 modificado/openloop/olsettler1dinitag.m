TSS_1 = 12.4969;
TSS_2 = 18.1132;
TSS_3 = 29.5402;
TSS_4 = 68.9781;
TSS_5 = 356.0747;
TSS_6 = 356.0747;
TSS_7 = 356.0747;
TSS_8 = 356.0747;
TSS_9 = 356.0747;
TSS_10 = 6393.9844;

SI_1 = 30;
SI_2 = 30;
SI_3 = 30;
SI_4 = 30;
SI_5 = 30;
SI_6 = 30;
SI_7 = 30;
SI_8 = 30;
SI_9 = 30;
SI_10 = 30;

SS_1 = 0.88949;
SS_2 = 0.88949;
SS_3 = 0.88949;
SS_4 = 0.88949;
SS_5 = 0.88949;
SS_6 = 0.88949;
SS_7 = 0.88949;
SS_8 = 0.88949;
SS_9 = 0.88949;
SS_10 = 0.88949;

SO_1 = 0.49094;
SO_2 = 0.49094;
SO_3 = 0.49094;
SO_4 = 0.49094;
SO_5 = 0.49094;
SO_6 = 0.49094;
SO_7 = 0.49094;
SO_8 = 0.49094;
SO_9 = 0.49094;
SO_10 = 0.49094;

SNO_1 = 10.4152;
SNO_2 = 10.4152;
SNO_3 = 10.4152;
SNO_4 = 10.4152;
SNO_5 = 10.4152;
SNO_6 = 10.4152;
SNO_7 = 10.4152;
SNO_8 = 10.4152;
SNO_9 = 10.4152;
SNO_10 = 10.4152;

SNH_1 = 1.7333;
SNH_2 = 1.7333;
SNH_3 = 1.7333;
SNH_4 = 1.7333;
SNH_5 = 1.7333;
SNH_6 = 1.7333;
SNH_7 = 1.7333;
SNH_8 = 1.7333;
SNH_9 = 1.7333;
SNH_10 = 1.7333;

SND_1 = 0.68828;
SND_2 = 0.68828;
SND_3 = 0.68828;
SND_4 = 0.68828;
SND_5 = 0.68828;
SND_6 = 0.68828;
SND_7 = 0.68828;
SND_8 = 0.68828;
SND_9 = 0.68828;
SND_10 = 0.68828;

SALK_1 = 4.1256;
SALK_2 = 4.1256;
SALK_3 = 4.1256;
SALK_4 = 4.1256;
SALK_5 = 4.1256;
SALK_6 = 4.1256;
SALK_7 = 4.1256;
SALK_8 = 4.1256;
SALK_9 = 4.1256;
SALK_10 = 4.1256;

X_Ag_1 = 0.0; % nanoparticulas de 30nm en cada una de las capas %
X_Ag_2 = 0.0;
X_Ag_3 = 0.0;
X_Ag_4 = 0.0;
X_Ag_5 = 0.0;
X_Ag_6 = 0.0;
X_Ag_7 = 0.0;
X_Ag_8 = 0.0;
X_Ag_9 = 0.0;
X_Ag_10 = 0.0;

S_AgI_1 = 0.0; % ion plata
S_AgI_2 = 0.0;
S_AgI_3 = 0.0;
S_AgI_4 = 0.0;
S_AgI_5 = 0.0;
S_AgI_6 = 0.0;
S_AgI_7 = 0.0;
S_AgI_8 = 0.0;
S_AgI_9 = 0.0;
S_AgI_10 = 0.0;

Sul1 = 0.0; % concentracion de sulfuro HS- y H2S % 
Sul2 = 0.0;
Sul3 = 0.0;
Sul4 = 0.0;
Sul5 = 0.0;
Sul6 = 0.0;
Sul7 = 0.0;
Sul8 = 0.0;
Sul9 = 0.0;
Sul10 = 0.0;

SETTLERINIT = [ TSS_1 TSS_2 TSS_3 TSS_4 TSS_5 TSS_6 TSS_7 TSS_8 TSS_9 TSS_10  SI_1 SI_2 SI_3 SI_4 SI_5 SI_6 SI_7 SI_8 SI_9 SI_10  SS_1 SS_2 SS_3 SS_4 SS_5 SS_6 SS_7 SS_8 SS_9 SS_10  SO_1 SO_2 SO_3 SO_4 SO_5 SO_6 SO_7 SO_8 SO_9 SO_10  SNO_1 SNO_2 SNO_3 SNO_4 SNO_5 SNO_6 SNO_7 SNO_8 SNO_9 SNO_10  SNH_1 SNH_2 SNH_3 SNH_4 SNH_5 SNH_6 SNH_7 SNH_8 SNH_9 SNH_10 SND_1 SND_2 SND_3 SND_4 SND_5 SND_6 SND_7 SND_8 SND_9 SND_10  SALK_1 SALK_2 SALK_3 SALK_4 SALK_5 SALK_6 SALK_7 SALK_8 SALK_9 SALK_10 X_Ag_1 X_Ag_2 X_Ag_3 X_Ag_4 X_Ag_5 X_Ag_6 X_Ag_7 X_Ag_8 X_Ag_9 X_Ag_10 S_AgI_1 S_AgI_2 S_AgI_3 S_AgI_4 S_AgI_5 S_AgI_6 S_AgI_7 S_AgI_8 S_AgI_9 S_AgI_10 Sul1 Sul2 Sul3 Sul4 Sul5 Sul6 Sul7 Sul8 Sul9 Sul10 ];
% SETTLERINIT tiene 80+20+10= 110 componente ahora %

v0_max = 250;
v0 = 474;
r_h = 0.000576;
r_p = 0.00286;
f_ns = 0.00228;
X_t = 3000;

SETTLERPAR = [ v0_max v0 r_h r_p f_ns X_t ];

 
area = 1500;
height = 4;

DIM = [ area height ];


feedlayer = 5;
nooflayers = 10;

LAYER = [ feedlayer nooflayers ];

% to use model with 10 layers for solubles use type 0 (COST Benchmark)
% to use model with 1 layer for solubles use type 1 (GSP-X implementation)
% to use model with 0 layers for solubles use type 2 (WEST implementation)

MODELTYPE = [ 0 ];
