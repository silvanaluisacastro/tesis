load sensornoise;
asm1init;
settler1dinit;
reginit;
sensorinit;
%eqinit;
load dryinfluent;
load storminfluent;
load raininfluent;
load constinfluent;

