olasm1init;

olsettler1dinit;

load constinfluent;
load dryinfluent;
load raininfluent;
load storminfluent;
